/*
 *  65xx Assembler
 *  (c) 1995, Pete Rittwage.
 *
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "opcodes.h"

#define ABS(x) ((x)<0?-(x):(x))
#define MAX(x,y) ((x)>(y)?(x):(y))
                             
#define MAX_JUMP 100
#define MAX_VAR 100                             
                             
/* PROTOS */
int main(int,char **);
int _prescan(void);
int _iconvert(char *,int *);
int _assemble(void);
char *_gettoken(void);
int _checkmode(void);  
int stch_i(char *, int);       
int stcd_i(char *);

// globals
int atari=1;  // turns off putting the load address in first 2 bytes
int halt=0;
int address=0;			
int codestart=0;
int code_size=0;
int numlabels=0;
int numvars=0;
int varstart=0x90; // start of 2600 variable space (first occurrance)
char target[10];
FILE *src,*dest;

struct jump_table
{
	int location;
	char label[10];
} jump[MAX_JUMP];

struct var_table
{
	int length;
	char location[5];	
	char label[10];
} var[MAX_VAR];


int main(int argc,char **argv)
{
	char src_name[16], dest_name[16];

	printf("\n\n65xx Compatible Assembler\n");
	printf("Copyright (c) 1995 by Pete Rittwage,\nAll rights reserved and that kinda stuff.\n\n");
		
	if(argc!=2)
	{
		printf("Argument count incorrect.\nUsage: ASS [source_file]\n");
	}
	else
	{
		sprintf(src_name,"%s.a",argv[1]);	
		sprintf(dest_name,"%s.ml",argv[1]);

		if(!(src=fopen(src_name,"rb")))
		{
			printf("Can't open file %s\n",src_name);
			printf("Nothing to assemble.\nUsage: ass [source file{.a}]\n");
		}
		else
		{
			if(!(dest=fopen(dest_name,"wb")))
			{	
				printf("Can't open output file %s\n",dest_name);
				fclose(src);
			}
			else
			{
				if(_prescan()==255) return(0);
				if(_assemble()==255) return(0);
				else printf("\nAssembled successfully to file '%s'.\nFinal output file size = %d ($%x) bytes\n",dest_name,code_size,code_size);
			}
		}
	}
	return(0);
}

int _prescan(void)
{
	int loop=0,z=0;
	int tempaddress=0,numbytes=0;	
	char label[10],temp[1];
	char startaddress[6];
	char tempbyte[2];
	
	if(strcmp(_gettoken(),"BEGIN"))
	{
		printf("No Start Address Defined\n");
		return(255);
	}
	strcpy(startaddress,_gettoken());
	z=stch_i(&startaddress[3],2);
	if(!atari) fputc(z,dest);
	tempbyte[0]=startaddress[1]; tempbyte[1]=startaddress[2];
	z=stch_i(tempbyte,2);
	if(!atari) fputc(z,dest);
	printf("Start Address = %s\n\n",startaddress);
	tempaddress=stch_i(&startaddress[1],4);
	address=codestart=tempaddress;	

	printf("Pass 1 - Scanning for Variables...\n");
	while(!feof(src))
	{
		strcpy(label,_gettoken());
		if(label[0]==';')
		{
			strcpy(var[loop].label,&label[1]);
			strcpy(temp,_gettoken());
			var[loop].length=stcd_i(temp);
			sprintf(var[loop].location,"%0.4x",varstart);
			printf("Variable found: %s assigned %d byte(s) @ $%s\n",var[loop].label,var[loop].length,var[loop].location);
			varstart+=var[loop].length;
			loop++;
		}
	}
	numvars=loop;

	printf("\nPass 2 - Scanning for Labels and Modes...\n");
	rewind(src);
	loop=0;
	while(!feof(src))
	{
		strcpy(label,_gettoken());
		if(label[0]==':')
		{
			printf("Label found: %s @ $%0.4x\n",&label[1],tempaddress);
			jump[loop].location=tempaddress;
			strcpy(jump[loop].label,&label[1]);
			loop++;
		}
		if(!(_iconvert(label,&numbytes)==255)) tempaddress+=numbytes;			
	}
	numlabels=loop;
}

int _assemble(void)
{
	char token[10],tempbyte[2],temp[4];
	int opcode=0,numbytes=0;
	int loop=0,x=0,z=0;	
	
	rewind(src);
	printf("\nPass 3 - Assembling...\n");

	while((!feof(src))&&(!halt))
	{
		strcpy(token,_gettoken());
		opcode=_iconvert(token,&numbytes);		
		
		switch(opcode)
		{
			case OP_NOP:	fputc(opcode,dest);
								address+=numbytes;
								break;
			
			case OP_ADC_ZERO_0:
			case OP_ADC_ZERO_X:
			case OP_AND_ZERO_0:
			case OP_AND_ZERO_X:
			case OP_ASL_ZERO_0:
			case OP_ASL_ZERO_X:
			case OP_CMP_ZERO_0:
			case OP_CMP_ZERO_X:
			case OP_CPX_ZERO:
			case OP_CPY_ZERO:
			case OP_DEC_ZERO_0:
			case OP_DEC_ZERO_X:
			case OP_EOR_ZERO_0:
			case OP_EOR_ZERO_X:
			case OP_INC_ZERO_0:
			case OP_INC_ZERO_X:
			case OP_LDA_ZERO_0:
			case OP_LDA_ZERO_X:
			case OP_LDX_ZERO_0:
			case OP_LDX_ZERO_Y:
			case OP_LDY_ZERO_0:
			case OP_LDY_ZERO_X:
			case OP_LSR_ZERO_0:
			case OP_LSR_ZERO_X:
			case OP_ORA_ZERO_0:
			case OP_ORA_ZERO_X:
			case OP_ROL_ZERO_0:
			case OP_ROL_ZERO_X:
			case OP_ROR_ZERO_0:
			case OP_ROR_ZERO_X:
			case OP_SBC_ZERO_0:
			case OP_SBC_ZERO_X:
			case OP_STA_ZERO_0:
			case OP_STA_ZERO_X:
			case OP_STX_ZERO_0:
			case OP_STX_ZERO_Y:
			case OP_STY_ZERO_0:
			case OP_STY_ZERO_X:
			case OP_SBC_IMMEDIATE:
			case OP_ORA_IMMEDIATE:
			case OP_EOR_IMMEDIATE:
			case OP_AND_IMMEDIATE:
			case OP_ADC_IMMEDIATE:
			case OP_CMP_IMMEDIATE:
			case OP_CPY_IMMEDIATE:
			case OP_CPX_IMMEDIATE:	
			case OP_LDX_IMMEDIATE:
			case OP_LDY_IMMEDIATE:
			case OP_LDA_IMMEDIATE:	fputc(opcode,dest);
											tempbyte[0]=target[1]; tempbyte[1]=target[2];
											z=stch_i(tempbyte,2);
											fputc(z,dest);
											address+=numbytes;
											break;		

			case OP_CMP_INDIRECT_X:
			case OP_CMP_INDIRECT_Y:
			case OP_EOR_INDIRECT_X:
			case OP_EOR_INDIRECT_Y:
			case OP_LDA_INDIRECT_X:
			case OP_LDA_INDIRECT_Y:
			case OP_ORA_INDIRECT_X:
			case OP_ORA_INDIRECT_Y:
			case OP_SBC_INDIRECT_X:
			case OP_SBC_INDIRECT_Y:
			case OP_STA_INDIRECT_X:
			case OP_STA_INDIRECT_Y:
			case OP_AND_INDIRECT_X:
			case OP_AND_INDIRECT_Y:
			case OP_ADC_INDIRECT_Y:
			case OP_ADC_INDIRECT_X:	fputc(opcode,dest);
											tempbyte[0]=target[2]; tempbyte[1]=target[3];
											z=stch_i(tempbyte,2);
											fputc(z,dest);
											address+=numbytes;
											break;		
			
			case OP_ROL_ABSOLUTE_0:
			case OP_ROL_ABSOLUTE_X:
			case OP_ROR_ABSOLUTE_0:
			case OP_ROR_ABSOLUTE_X:
			case OP_LSR_ABSOLUTE_0:
			case OP_LSR_ABSOLUTE_X:
			case OP_BIT_ABSOLUTE:
			case OP_ASL_ABSOLUTE_0:
			case OP_ASL_ABSOLUTE_X:
			case OP_SBC_ABSOLUTE_0:
			case OP_SBC_ABSOLUTE_X:
			case OP_SBC_ABSOLUTE_Y:
			case OP_ORA_ABSOLUTE_0:
			case OP_ORA_ABSOLUTE_X:
			case OP_ORA_ABSOLUTE_Y:
			case OP_EOR_ABSOLUTE_0:
			case OP_EOR_ABSOLUTE_X:
			case OP_EOR_ABSOLUTE_Y:
			case OP_AND_ABSOLUTE_0:
			case OP_AND_ABSOLUTE_X:
			case OP_AND_ABSOLUTE_Y:
			case OP_CMP_ABSOLUTE_0:
			case OP_CMP_ABSOLUTE_X:
			case OP_CMP_ABSOLUTE_Y:
			case OP_CPX_ABSOLUTE:
			case OP_CPY_ABSOLUTE:
			case OP_LDA_ABSOLUTE_0:
			case OP_LDA_ABSOLUTE_X:
			case OP_LDA_ABSOLUTE_Y:	
			case OP_LDY_ABSOLUTE_0:
			case OP_LDY_ABSOLUTE_X:
			case OP_LDX_ABSOLUTE_0:
			case OP_LDX_ABSOLUTE_Y:	
			case OP_ADC_ABSOLUTE_0:
			case OP_ADC_ABSOLUTE_X:
			case OP_ADC_ABSOLUTE_Y:
			case OP_INC_ABSOLUTE_0:
			case OP_INC_ABSOLUTE_X:
			case OP_DEC_ABSOLUTE_0:
			case OP_DEC_ABSOLUTE_X:
			case OP_STA_ABSOLUTE_0:
			case OP_STA_ABSOLUTE_X:
			case OP_STA_ABSOLUTE_Y:
			case OP_STX_ABSOLUTE:
			case OP_STY_ABSOLUTE:	fputc(opcode,dest);

											if(target[strlen(target)-2]==',') target[strlen(target)-2]='\0';
											
											if(target[0]=='-')
											{
												for(x=0;x<numvars;x++)
												{
													if(!strcmp(var[x].label,&target[1]))
													{
														z=stch_i(&var[x].location[2],2);
														fputc(z,dest);
														tempbyte[0]=var[x].location[0]; tempbyte[1]=var[x].location[1];
														z=stch_i(tempbyte,2);
														fputc(z,dest);
													}
												}
											}
											if(target[0]=='$')
											{
												z=stch_i(&target[3],2);
												fputc(z,dest);
												tempbyte[0]=target[1]; tempbyte[1]=target[2];
												z=stch_i(tempbyte,2);
												fputc(z,dest);
											}
											address+=numbytes;
											break;
				
			case OP_BCC:
			case OP_BCS:
			case OP_BMI:
			case OP_BPL:
			case OP_BVC:
			case OP_BVS:
			case OP_BNE:
			case OP_BEQ:	fputc(opcode,dest);
								for(x=0;x<numlabels;x++)
								{
									if(!strcmp(jump[x].label,&target[1]))
									{
										if(ABS(address-jump[x].location)>127)
										{
											printf("Branch out of range.\n");
											return(255);
										}
										if(address>jump[x].location) z=256-2-(address-jump[x].location); 
										else z=(jump[x].location-address)-2;
										printf("Relative Branch to $%0.4x (%s)\n",jump[x].location,jump[x].label);
										fputc(z,dest);
									}
								}
								address+=numbytes;
								break;

			case OP_JMP_ABSOLUTE:
			case OP_JSR:				fputc(opcode,dest);
											if(target[0]=='!')
											{
												for(x=0;x<numlabels;x++)
												{
													if(!strcmp(jump[x].label,&target[1]))
													{
														printf("Absolute JMP/JSR to $%0.4x (%s)\n",jump[x].location,jump[x].label);
														sprintf(temp,"%0.4x",jump[x].location);
														z=stch_i(&temp[2],2);
														fputc(z,dest);
														tempbyte[0]=temp[0]; tempbyte[1]=temp[1];
														z=stch_i(tempbyte,2);
														fputc(z,dest);
													}
												}
											}
											if(target[0]=='$')
											{
												printf("Absolute JMP/JSR to $%s\n",&target[1]);
												z=stch_i(&target[3],2);
												fputc(z,dest);
												tempbyte[0]=target[1]; tempbyte[1]=target[2];
												z=stch_i(tempbyte,2);
												fputc(z,dest);
											}
											address+=numbytes;
											break;
		
			case OP_TAX:
			case OP_TAY:
			case OP_TSX:
			case OP_TXA:
			case OP_TXS:
			case OP_TYA:
			case OP_SEC:
			case OP_SED:
			case OP_SEI:
			case OP_PHA:
			case OP_PHP:
			case OP_PLA:
			case OP_PLP:
			case OP_RTI:
			case OP_RTS:
			case OP_CLD:
			case OP_CLI:
			case OP_CLV:
			case OP_CLC:
			case OP_DEX:
			case OP_DEY:
			case OP_INX:	
			case OP_INY:	fputc(opcode,dest);
								address+=numbytes;		
								break;

			case OP_BRK:	fputc(0,dest);
								address+=numbytes;
								break;

			case OP_END:	fclose(src);
								fclose(dest);
								code_size=address-codestart+2;
								return(0);

			/* ERROR! */
			case 255:		break;
			
			default:			printf("An unknown error occurred.\n");
								return(255);
		}
		loop++;
	}
	printf("Assembly halted!\n");
	return(255);
}

int _iconvert(char *instr, int *x)
{
	if(!strcmp(instr,"END")) { *x=0; return(OP_END); }
	if(!strcmp(instr,"BRK")) { *x=1; return(OP_BRK); }
	if(!strcmp(instr,"NOP")) { *x=1; return(OP_NOP); }

	if(!strcmp(instr,"INX")) { *x=1; return(OP_INX); }
	if(!strcmp(instr,"INY")) { *x=1; return(OP_INY); }
	if(!strcmp(instr,"DEX")) { *x=1; return(OP_DEX); }
	if(!strcmp(instr,"DEY")) { *x=1; return(OP_DEY); }	

	if(!strcmp(instr,"BNE")) { *x=2; strcpy(target,_gettoken()); return(OP_BNE); }
	if(!strcmp(instr,"BEQ")) { *x=2; strcpy(target,_gettoken()); return(OP_BEQ); }
	if(!strcmp(instr,"BCC")) { *x=2; strcpy(target,_gettoken()); return(OP_BCC); }
	if(!strcmp(instr,"BCS")) { *x=2; strcpy(target,_gettoken()); return(OP_BCS); }
	if(!strcmp(instr,"BMI")) { *x=2; strcpy(target,_gettoken()); return(OP_BMI); }
	if(!strcmp(instr,"BPL")) { *x=2; strcpy(target,_gettoken()); return(OP_BPL); }
	if(!strcmp(instr,"BVC")) { *x=2; strcpy(target,_gettoken()); return(OP_BVC); }
	if(!strcmp(instr,"BVS")) { *x=2; strcpy(target,_gettoken()); return(OP_BVS); }

	if(!strcmp(instr,"CLC")) { *x=1; strcpy(target,_gettoken()); return(OP_CLC); }
	if(!strcmp(instr,"CLD")) { *x=1; strcpy(target,_gettoken()); return(OP_CLD); }
	if(!strcmp(instr,"CLI")) { *x=1; strcpy(target,_gettoken()); return(OP_CLI); }
	if(!strcmp(instr,"CLV")) { *x=1; strcpy(target,_gettoken()); return(OP_CLV); }

	if(!strcmp(instr,"PHA")) { *x=1; strcpy(target,_gettoken()); return(OP_PHA); }	
	if(!strcmp(instr,"PHP")) { *x=1; strcpy(target,_gettoken()); return(OP_PHP); }
	if(!strcmp(instr,"PLA")) { *x=1; strcpy(target,_gettoken()); return(OP_PLA); }
	if(!strcmp(instr,"PLP")) { *x=1; strcpy(target,_gettoken()); return(OP_PLP); }
	if(!strcmp(instr,"RTI")) { *x=1; strcpy(target,_gettoken()); return(OP_RTI); }
	if(!strcmp(instr,"RTS")) { *x=1; strcpy(target,_gettoken()); return(OP_RTS); }

	if(!strcmp(instr,"SEC")) { *x=1; strcpy(target,_gettoken()); return(OP_SEC); }
	if(!strcmp(instr,"SED")) { *x=1; strcpy(target,_gettoken()); return(OP_SED); }
	if(!strcmp(instr,"SEI")) { *x=1; strcpy(target,_gettoken()); return(OP_SEI); }

	if(!strcmp(instr,"TAX")) { *x=1; strcpy(target,_gettoken()); return(OP_TAX); }
	if(!strcmp(instr,"TAY")) { *x=1; strcpy(target,_gettoken()); return(OP_TAY); }
	if(!strcmp(instr,"TSX")) { *x=1; strcpy(target,_gettoken()); return(OP_TSX); }
	if(!strcmp(instr,"TXA")) { *x=1; strcpy(target,_gettoken()); return(OP_TXA); }
	if(!strcmp(instr,"TXS")) { *x=1; strcpy(target,_gettoken()); return(OP_TXS); }
	if(!strcmp(instr,"TYA")) { *x=1; strcpy(target,_gettoken()); return(OP_TYA); }

	if(!strcmp(instr,"JMP")) { *x=3; strcpy(target,_gettoken()); return(OP_JMP_ABSOLUTE); }
	if(!strcmp(instr,"JSR")) { *x=3; strcpy(target,_gettoken()); return(OP_JSR); }

	if(!strcmp(instr,"ADC"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 1:	*x=2; return(OP_ADC_IMMEDIATE); 
			case 2:	*x=2; return(OP_ADC_ZERO_0);
			case 3:	*x=2; return(OP_ADC_ZERO_X);
			case 4:	*x=3; return(OP_ADC_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_ADC_ABSOLUTE_X);
			case 6:	*x=3;	return(OP_ADC_ABSOLUTE_Y);
			case 7:	*x=2;	return(OP_ADC_INDIRECT_X);
			case 8:	*x=2; return(OP_ADC_INDIRECT_Y);
		
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"AND"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 1:	*x=2; return(OP_AND_IMMEDIATE); 
			case 2:	*x=2; return(OP_AND_ZERO_0);
			case 3:	*x=2; return(OP_AND_ZERO_X);
			case 4:	*x=3; return(OP_AND_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_AND_ABSOLUTE_X);
			case 6:	*x=3;	return(OP_AND_ABSOLUTE_Y);
			case 7:	*x=2;	return(OP_AND_INDIRECT_X);
			case 8:	*x=2; return(OP_AND_INDIRECT_Y);
		
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}
	
	if(!strcmp(instr,"ASL"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 2:	*x=2; return(OP_ASL_ZERO_0);
			case 3:	*x=2; return(OP_ASL_ZERO_X);
			case 4:	*x=3; return(OP_ASL_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_ASL_ABSOLUTE_X);
				
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"BIT"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 2:	*x=2; return(OP_BIT_ZERO);
			case 4:	*x=3; return(OP_BIT_ABSOLUTE);
				
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"EOR"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 1:	*x=2; return(OP_EOR_IMMEDIATE); 
			case 2:	*x=2; return(OP_EOR_ZERO_0);
			case 3:	*x=2; return(OP_EOR_ZERO_X);
			case 4:	*x=3; return(OP_EOR_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_EOR_ABSOLUTE_X);
			case 6:	*x=3;	return(OP_EOR_ABSOLUTE_Y);
			case 7:	*x=2;	return(OP_EOR_INDIRECT_X);
			case 8:	*x=2; return(OP_EOR_INDIRECT_Y);
		
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"ORA"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 1:	*x=2; return(OP_ORA_IMMEDIATE); 
			case 2:	*x=2; return(OP_ORA_ZERO_0);
			case 3:	*x=2; return(OP_ORA_ZERO_X);
			case 4:	*x=3; return(OP_ORA_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_ORA_ABSOLUTE_X);
			case 6:	*x=3;	return(OP_ORA_ABSOLUTE_Y);
			case 7:	*x=2;	return(OP_ORA_INDIRECT_X);
			case 8:	*x=2; return(OP_ORA_INDIRECT_Y);
		
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}	

	if(!strcmp(instr,"ROL"))
	{
		switch(_checkmode()) 
		{
			case 2:	*x=2; return(OP_ROL_ZERO_0);
			case 3:	*x=2; return(OP_ROL_ZERO_X);
			case 4:	*x=3; return(OP_ROL_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_ROL_ABSOLUTE_X);
					
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}
	
	if(!strcmp(instr,"ROR"))
	{
		switch(_checkmode()) 
		{
			case 2:	*x=2; return(OP_ROR_ZERO_0);
			case 3:	*x=2; return(OP_ROR_ZERO_X);
			case 4:	*x=3; return(OP_ROR_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_ROR_ABSOLUTE_X);
					
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"SBC"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 1:	*x=2; return(OP_SBC_IMMEDIATE); 
			case 2:	*x=2; return(OP_SBC_ZERO_0);
			case 3:	*x=2; return(OP_SBC_ZERO_X);
			case 4:	*x=3; return(OP_SBC_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_SBC_ABSOLUTE_X);
			case 6:	*x=3;	return(OP_SBC_ABSOLUTE_Y);
			case 7:	*x=2;	return(OP_SBC_INDIRECT_X);
			case 8:	*x=2; return(OP_SBC_INDIRECT_Y);
		
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}	

	if(!strcmp(instr,"INC"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 2:	*x=2; return(OP_INC_ZERO_0);
			case 3:	*x=2; return(OP_INC_ZERO_X);
			case 4:	*x=3; return(OP_INC_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_INC_ABSOLUTE_X);
					
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}	
	
	if(!strcmp(instr,"DEC"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 2:	*x=2; return(OP_AND_ZERO_0);
			case 3:	*x=2; return(OP_AND_ZERO_X);
			case 4:	*x=3; return(OP_AND_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_AND_ABSOLUTE_X);
				
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}	

	if(!strcmp(instr,"LDA"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 1:	*x=2; return(OP_LDA_IMMEDIATE); 
			case 2:	*x=2; return(OP_LDA_ZERO_0);
			case 3:	*x=2; return(OP_LDA_ZERO_X);
			case 4:	*x=3; return(OP_LDA_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_LDA_ABSOLUTE_X);
			case 6:	*x=3;	return(OP_LDA_ABSOLUTE_Y);
			case 7:	*x=2;	return(OP_LDA_INDIRECT_X);
			case 8:	*x=2; return(OP_LDA_INDIRECT_Y);
		
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"LDX"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 1:	*x=2; return(OP_LDX_IMMEDIATE); 
			case 2:	*x=2; return(OP_LDX_ZERO_0);
			case 3:	*x=2; return(OP_LDX_ZERO_Y);
			case 4:	*x=3; return(OP_LDX_ABSOLUTE_0);
			case 6:	*x=3;	return(OP_LDX_ABSOLUTE_Y);
					
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"LDY"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 1:	*x=2; return(OP_LDY_IMMEDIATE); 
			case 2:	*x=2; return(OP_LDY_ZERO_0);
			case 3:	*x=2; return(OP_LDY_ZERO_X);
			case 4:	*x=3; return(OP_LDY_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_LDY_ABSOLUTE_X);
					
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"LSR"))
	{
		switch(_checkmode()) 
		{
			case 2:	*x=2; return(OP_LSR_ZERO_0);
			case 3:	*x=2; return(OP_LSR_ZERO_X);
			case 4:	*x=3; return(OP_LSR_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_LSR_ABSOLUTE_X);
					
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"CMP"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 1:	*x=2; return(OP_CMP_IMMEDIATE); 
			case 2:	*x=2; return(OP_CMP_ZERO_0);
			case 3:	*x=2; return(OP_CMP_ZERO_X);
			case 4:	*x=3; return(OP_CMP_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_CMP_ABSOLUTE_X);
			case 6:	*x=3;	return(OP_CMP_ABSOLUTE_Y);
			case 7:	*x=2;	return(OP_CMP_INDIRECT_X);
			case 8:	*x=2; return(OP_CMP_INDIRECT_Y);
		
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"CPX"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 1:	*x=2; return(OP_CPX_IMMEDIATE); 
			case 2:	*x=2; return(OP_CPX_ZERO);
			case 4:	*x=3; return(OP_CPX_ABSOLUTE);
					
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"CPY"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 1:	*x=2; return(OP_CPY_IMMEDIATE); 
			case 2:	*x=2; return(OP_CPY_ZERO);
			case 4:	*x=3; return(OP_CPY_ABSOLUTE);
					
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"STA"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 2:	*x=2; return(OP_STA_ZERO_0);
			case 3:	*x=2; return(OP_STA_ZERO_X);
			case 4:	*x=3; return(OP_STA_ABSOLUTE_0);
			case 5:	*x=3;	return(OP_STA_ABSOLUTE_X);
			case 6:	*x=3;	return(OP_STA_ABSOLUTE_Y);
			case 7:	*x=2;	return(OP_STA_INDIRECT_X);
			case 8:	*x=2; return(OP_STA_INDIRECT_Y);
		
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"STX"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 2:	*x=2; return(OP_STX_ZERO_0);
			case 3:	*x=2; return(OP_STX_ZERO_Y);
			case 4:	*x=3; return(OP_STX_ABSOLUTE);
				
			default:	printf("ERROR! - Unknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}

	if(!strcmp(instr,"STY"))
	{
		strcpy(target,_gettoken());
		switch(_checkmode()) 
		{
			case 2:	*x=2; return(OP_STY_ZERO_0);
			case 3:	*x=2; return(OP_STY_ZERO_X);
			case 4:	*x=3; return(OP_STY_ABSOLUTE);
					
			default:	printf("ERROR!\nUnknown address mode:  %s %s.\n",instr,target);
						halt++; return(255);
		}
	}	
	return(255); 
}

int _checkmode(void)
{
	if((target[0]=='#')&&(3==strlen(target))) return(1);
	if((target[0]=='$')&&(3==strlen(target))) return(2);
	if((target[0]=='$')&&(target[3]==',')) return(3);
	
	if((target[0]=='$')&&(5==strlen(target))) return(4);
	if((target[0]=='-')&&(target[strlen(target)-2]!=',')) return(4);

	if((target[0]=='$')&&(target[6]=='X')) return(5);
	if((target[0]=='-')&&(target[strlen(target)-1]=='X')) return(5);
	
	if((target[0]=='$')&&(target[6]=='Y')) return(6);
	if((target[0]=='-')&&(target[strlen(target)-1]=='Y')) return(6);
	
	if((target[0]=='(')&&(target[strlen(target)-1]==')')) return(7);

	if((target[0]=='(')&&(target[strlen(target)-1]=='Y')) return(8);

	return(255);
}

char *_gettoken(void)
{
	int x;
	char token[10];

	while(!feof(src))
	{
		x=fgetc(src);
		if(x=='/') for(x=0;x!='/';x=fgetc(src));	
		if((isalnum(x))||(x=='-')||(x==':')||(x=='!')||(x=='#')||(x==';')||(x=='$')||(x=='('))
		{
			fseek(src,-1,1);
			fscanf(src,"%s",token);
			return(token);
		}	
	}
}
          
int stch_i(char *text, int length)
{                                    
	// having to actually write this sucks!
	int hex=0;
	
	if(length==4)
	{
	   // First char of 4 byte hex number
		if(text[0]<='9') hex=text[0]-'0';
		else
			if(text[0]<='F') hex=text[0]-'A'+10;
			else hex=text[0]-'a'+10;
		hex<<=4;
   
		//Second char of 4 byte.
		if(text[1]<='9') hex|=text[1]-'0';
		else
			if(text[1]<='F') hex|=text[1]-'A'+10;
			else hex|=text[1]-'a'+10;
		hex<<=4;

		//Third char of 4 byte.
		if(text[2]<='9') hex|=text[2]-'0';
		else
			if(text[2]<='F') hex|=text[2]-'A'+10;
			else hex|=text[2]-'a'+10;
		hex<<=4;
		
		//Last char of 4 byte.
		if(text[3]<='9') hex|=text[3]-'0';
		else
			if(text[3]<='F') hex|=text[3]-'A'+10;
			else hex|=text[3]-'a'+10;
	}
	else if(length==2)
	{
	   // First char of 2 byte hex number
		if(text[0]<='9') hex=text[0]-'0';
		else
			if(text[0]<='F') hex=text[0]-'A'+10;
			else hex=text[0]-'a'+10;
		hex<<=4;
   
		//Second char of 2 byte.
		if(text[1]<='9') hex|=text[1]-'0';
		else
			if(text[1]<='F') hex|=text[1]-'A'+10;
			else hex|=text[1]-'a'+10;
	}
   else printf("I can only convert 2 and 4 byte hex numbers!\n");
	
	return(hex);
}
              
int stcd_i(char *text)
{       
	int dec=0;

	if(strlen(text)==2)
	{
		// First char of 2 byte number
		dec=text[0]-'0';
		dec<<=4;
		// second char
		dec|=text[1]-'0';
	}
	else if(strlen(text)==1)
	{
		// only byte.
		dec=text[0]-'0';
	}
	else printf("Unknown number of bytes for stcd_i\n");
	
	return(dec);
}